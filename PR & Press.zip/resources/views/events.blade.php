@extends('layouts.frontend.app')

@section('title')
<title>Events | PR and Press</title>
@endsection

@section('content')
<!--------------------------event-banner-------------->
<div class="event_banner">
    <div class="container">
        <div class="event_text">
            <a href="./index.html">Home</a>
            <a href="./events.html" class="event_btn">Events</a>
        </div>
        <div class="event_box">
            <a href="#"><i class="fa fa-plus" aria-hidden="true"></i> Create Event</a>
        </div>
    </div>
</div>
<!-------------------------event-section-------------------->
<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="event_section">
                <div class="event_img">
                    <img src="{{asset('assets/image/no-img.jpg')}}" alt="blog-1">
                </div>
                <div class="event_text2">
                    <span class="event_by"><i class="fa fa-tag" aria-hidden="true"></i> | by Manish Kumar</span>
                    <h4>
                        <a href="#">EVENT 15th AUG</a>
                    </h4>
                    <p>Independence day of India. </p>
                    <span class="map"></span><i class="fa fa-map-marker" aria-hidden="true"></i> Delhi</span>
                </div>
                <div class="calendar">
                    <div class="calendar_box">
                        Aug, 2022
                        <h4>29</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12">
            <div class="event_section">
                <div class="event_img">
                    <img src="{{asset('assets/image/no-img.jpg')}}" alt="blog-1">
                </div>
                <div class="event_text2">
                    <span class="event_by"><i class="fa fa-tag" aria-hidden="true"></i> | by Manish Kumar</span>
                    <h4>
                        <a href="#">test</a>
                    </h4>
                    <p>test</p>
                    <span class="map"></span><i class="fa fa-map-marker" aria-hidden="true"></i> Delhi</span>
                </div>
                <div class="calendar">
                    <div class="calendar_box">
                        Apr, 2022
                        <h4>5</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12">
            <div class="event_section">
                <div class="event_img">
                    <img src="{{asset('assets/image/no-img.jpg')}}" alt="blog-1">
                </div>
                <div class="event_text2">
                    <span class="event_by"><i class="fa fa-tag" aria-hidden="true"></i> | by Manish Kumar</span>
                    <h4>
                        <a href="#">BW Disrupt 40 Under 40</a>
                    </h4>
                    <p>BW Disrupt 40 Under 40<br>
                        <b>Organizer</b> - E4M<br>
                        <b>Speaker</b> - To be detailed

                    </p>
                    <span class="map"><i class="fa fa-map-marker" aria-hidden="true"></i> Online</span>
                </div>
                <div class="calendar">
                    <div class="calendar_box">
                        Jan, 2022
                        <h4>1</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')

@endsection