<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/billu/Data/Professional/Laravel/pr&prpress/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>