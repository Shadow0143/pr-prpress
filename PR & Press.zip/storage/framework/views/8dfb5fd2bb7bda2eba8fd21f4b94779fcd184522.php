<?php $__env->startSection('title'); ?>
<title>Social Connects | PR and Press</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--------------------------event-banner-------------->
<div class="event_banner">
    <div class="container">
        <div class="event_text">
            <a href="./index.html">Home</a>
            <a href="./social.html" class="event_btn">Social</a>
        </div>
    </div>
</div>
<!-------------------------social------------------->
<div class="container">
    <div class="social">
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <div class="profile">
                    <div class="profile_img">
                        <img src="<?php echo e(asset('profile_pics')); ?>/<?php echo e($user->photo); ?>" alt="no-img">
                    </div>
                    <h5><?php echo e($user->name); ?></h5>
                    <p><?php echo e($user->email); ?></p>
                </div>
            </div>
            <div class="col-md-9 col-sm-9">
                <form action="<?php echo e(route('submitPosts')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group comment">
                        <textarea placeholder="Post your query here" type="text" formcontrolname="content"
                            class="form-control" name="post"></textarea>
                        <button class="btn btn-primary send" type="submit"><i class="fa fa-paper-plane"
                                aria-hidden="true"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/billu/Data/Professional/Laravel/pr&prpress/resources/views/social.blade.php ENDPATH**/ ?>